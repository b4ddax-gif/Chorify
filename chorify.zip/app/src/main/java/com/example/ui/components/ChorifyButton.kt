package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class ButtonStyle {
  PRIMARY_GOLD,
  SECONDARY_OUTLINE,
  SURFACE_ELEVATED,
  DANGER_RED
}

@Composable
fun ChorifyButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  style: ButtonStyle = ButtonStyle.PRIMARY_GOLD,
  enabled: Boolean = true,
  testTag: String = "chorify_button"
) {
  val shape = RoundedCornerShape(12.dp)

  when (style) {
    ButtonStyle.PRIMARY_GOLD -> {
      Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = RajaGold,
          contentColor = MysteryBlack,
          disabledContainerColor = RajaGold.copy(alpha = 0.35f),
          disabledContentColor = MysteryBlack.copy(alpha = 0.5f)
        ),
        modifier = modifier
          .fillMaxWidth()
          .defaultMinSize(minHeight = 52.dp)
          .testTag(testTag)
      ) {
        Text(
          text = text,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }
    }
    ButtonStyle.DANGER_RED -> {
      Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = ChorRed,
          contentColor = TextPrimary,
          disabledContainerColor = ChorRed.copy(alpha = 0.35f),
          disabledContentColor = TextSecondary
        ),
        modifier = modifier
          .fillMaxWidth()
          .defaultMinSize(minHeight = 52.dp)
          .testTag(testTag)
      ) {
        Text(
          text = text,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }
    }
    ButtonStyle.SECONDARY_OUTLINE -> {
      OutlinedButton(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        border = BorderStroke(1.dp, if (enabled) MysteryBorder else MysteryBorder.copy(alpha = 0.3f)),
        colors = ButtonDefaults.outlinedButtonColors(
          contentColor = TextPrimary,
          disabledContentColor = TextSecondary.copy(alpha = 0.5f)
        ),
        modifier = modifier
          .fillMaxWidth()
          .defaultMinSize(minHeight = 52.dp)
          .testTag(testTag)
      ) {
        Text(
          text = text,
          fontSize = 14.sp,
          fontWeight = FontWeight.SemiBold,
          letterSpacing = 0.75.sp
        )
      }
    }
    ButtonStyle.SURFACE_ELEVATED -> {
      Button(
        onClick = onClick,
        enabled = enabled,
        shape = shape,
        colors = ButtonDefaults.buttonColors(
          containerColor = MysteryElevatedSurface,
          contentColor = TextPrimary,
          disabledContainerColor = MysteryElevatedSurface.copy(alpha = 0.4f),
          disabledContentColor = TextSecondary.copy(alpha = 0.4f)
        ),
        border = BorderStroke(1.dp, MysteryBorder),
        modifier = modifier
          .fillMaxWidth()
          .defaultMinSize(minHeight = 52.dp)
          .testTag(testTag)
      ) {
        Text(
          text = text,
          fontSize = 14.sp,
          fontWeight = FontWeight.SemiBold,
          letterSpacing = 0.75.sp
        )
      }
    }
  }
}
