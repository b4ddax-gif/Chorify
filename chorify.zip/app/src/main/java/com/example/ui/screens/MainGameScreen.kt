package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameState
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.components.CornerChitCard
import com.example.ui.components.CornerPosition
import com.example.ui.theme.ChorRed
import com.example.ui.theme.ChorRedContainer
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MantriGreenContainer
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryBorderActive
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueContainer
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun MainGameScreen(
  state: GameState,
  onTapChit: (playerId: Int) -> Unit,
  onSelectSuspect: (playerId: Int) -> Unit,
  onConfirmGuess: () -> Unit,
  onRequestReveal: () -> Unit,
  onDismissRevealDialog: () -> Unit,
  onExecuteReveal: () -> Unit,
  onStartNextRound: () -> Unit,
  onProceedToRoundResult: () -> Unit,
  onScoreboardClick: () -> Unit,
  onSettingsClick: () -> Unit,
  isSoundOn: Boolean,
  onSoundToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  val p1 = state.playerTopLeft
  val p2 = state.playerTopRight
  val p3 = state.playerBottomLeft
  val p4 = state.playerBottomRight

  val chor = state.chorPlayer
  val mantri = state.mantriPlayer
  val police = state.policePlayer
  val raja = state.rajaPlayer

  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = "CHORIFY",
        subtitle = "Round ${state.currentRound} • 4-Corner Board",
        showBack = false,
        isSoundOn = isSoundOn,
        onSoundToggle = onSoundToggle,
        onScoreboardClick = onScoreboardClick,
        onSettingsClick = onSettingsClick
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.Center
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .widthIn(max = 520.dp)
          .padding(horizontal = 14.dp, vertical = 8.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
      ) {
        // TOP CORNERS ROW (PLAYER 1 = Top-Left, PLAYER 2 = Top-Right)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          if (p1 != null) {
            CornerChitCard(
              player = p1,
              corner = CornerPosition.TOP_LEFT,
              isSuspected = state.suspectedPlayerId == p1.id,
              isGuessConfirmed = state.isGuessConfirmed && state.suspectedPlayerId == p1.id,
              isChorRevealed = state.isChorRevealed,
              onChitTap = { onTapChit(p1.id) },
              onSuspectSelect = { onSelectSuspect(p1.id) },
              modifier = Modifier.weight(1f)
            )
          }

          if (p2 != null) {
            CornerChitCard(
              player = p2,
              corner = CornerPosition.TOP_RIGHT,
              isSuspected = state.suspectedPlayerId == p2.id,
              isGuessConfirmed = state.isGuessConfirmed && state.suspectedPlayerId == p2.id,
              isChorRevealed = state.isChorRevealed,
              onChitTap = { onTapChit(p2.id) },
              onSuspectSelect = { onSelectSuspect(p2.id) },
              modifier = Modifier.weight(1f)
            )
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // CENTER HUB (Board Game Centerpiece)
        Card(
          shape = RoundedCornerShape(20.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.5.dp, MysteryBorder),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("board_center_hub")
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
          ) {
            if (!state.isChorRevealed) {
              // Pre-reveal status and suspect indicator
              Text(
                text = "BOARD TABLETOP",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.5.sp
              )

              Spacer(modifier = Modifier.height(6.dp))

              // Hint/Status
              val anyChitOpened = state.players.any { it.isChitTapped }
              val statusMessage = when {
                !anyChitOpened -> "Each player should tap their own corner to see their role."
                state.suspectedPlayerId != null -> {
                  val suspect = state.players.firstOrNull { it.id == state.suspectedPlayerId }
                  "Accused: ${suspect?.name ?: ""}"
                }
                else -> "Police: discuss, deduce, then tap a suspect corner to accuse!"
              }

              Text(
                text = statusMessage,
                fontSize = 12.sp,
                fontWeight = FontWeight.Medium,
                color = if (state.suspectedPlayerId != null) ChorRed else TextSecondary,
                textAlign = TextAlign.Center
              )

              if (state.suspectedPlayerId != null && !state.isGuessConfirmed) {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                  onClick = onConfirmGuess,
                  shape = RoundedCornerShape(8.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = MysteryElevatedSurface,
                    contentColor = TextPrimary
                  ),
                  border = androidx.compose.foundation.BorderStroke(1.dp, ChorRed),
                  modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(36.dp)
                    .testTag("confirm_guess_button")
                ) {
                  Text(
                    text = "CONFIRM GUESS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = ChorRed,
                    letterSpacing = 0.5.sp
                  )
                }
              }

              Spacer(modifier = Modifier.height(12.dp))

              // LARGE CENTER REVEAL CHOR BUTTON
              Button(
                onClick = onRequestReveal,
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(
                  containerColor = RajaGold,
                  contentColor = MysteryBlack
                ),
                modifier = Modifier
                  .fillMaxWidth()
                  .height(54.dp)
                  .testTag("center_reveal_chor_button")
              ) {
                Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "REVEAL CHOR",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  letterSpacing = 2.sp
                )
              }
            } else {
              // POST-REVEAL CENTER DISPLAY
              val result = state.lastGuessResult

              Text(
                text = "THE CHOR IS...",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.5.sp
              )

              Spacer(modifier = Modifier.height(2.dp))

              Text(
                text = chor?.name ?: "Unknown",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = ChorRed,
                modifier = Modifier.testTag("center_revealed_chor_name")
              )

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                text = "THE MANTRI IS...",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                letterSpacing = 1.sp
              )

              Spacer(modifier = Modifier.height(2.dp))

              Text(
                text = mantri?.name ?: "Unknown",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                fontFamily = FontFamily.Serif,
                color = MantriGreen,
                modifier = Modifier.testTag("center_revealed_mantri_name")
              )

              Spacer(modifier = Modifier.height(8.dp))

              val verdictText = when {
                result?.isCorrect == true -> "Police guessed right! (+100 to Police)"
                result?.suspectedPlayerName != null -> "Police was fooled! (+100 to Chor)"
                else -> "No guess made! (+100 to Chor)"
              }

              Text(
                text = verdictText,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = if (result?.isCorrect == true) PoliceBlue else ChorRed,
                textAlign = TextAlign.Center
              )

              Spacer(modifier = Modifier.height(12.dp))

              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
              ) {
                Button(
                  onClick = onStartNextRound,
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = RajaGold,
                    contentColor = MysteryBlack
                  ),
                  modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("center_next_round_button")
                ) {
                  Text(
                    text = "NEXT ROUND",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                  )
                }

                Button(
                  onClick = onProceedToRoundResult,
                  shape = RoundedCornerShape(10.dp),
                  colors = ButtonDefaults.buttonColors(
                    containerColor = MysteryElevatedSurface,
                    contentColor = TextPrimary
                  ),
                  border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
                  modifier = Modifier
                    .weight(1f)
                    .height(44.dp)
                    .testTag("center_round_recap_button")
                ) {
                  Text(
                    text = "RECAP & STANDINGS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // BOTTOM CORNERS ROW (PLAYER 3 = Bottom-Left, PLAYER 4 = Bottom-Right)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          if (p3 != null) {
            CornerChitCard(
              player = p3,
              corner = CornerPosition.BOTTOM_LEFT,
              isSuspected = state.suspectedPlayerId == p3.id,
              isGuessConfirmed = state.isGuessConfirmed && state.suspectedPlayerId == p3.id,
              isChorRevealed = state.isChorRevealed,
              onChitTap = { onTapChit(p3.id) },
              onSuspectSelect = { onSelectSuspect(p3.id) },
              modifier = Modifier.weight(1f)
            )
          }

          if (p4 != null) {
            CornerChitCard(
              player = p4,
              corner = CornerPosition.BOTTOM_RIGHT,
              isSuspected = state.suspectedPlayerId == p4.id,
              isGuessConfirmed = state.isGuessConfirmed && state.suspectedPlayerId == p4.id,
              isChorRevealed = state.isChorRevealed,
              onChitTap = { onTapChit(p4.id) },
              onSuspectSelect = { onSelectSuspect(p4.id) },
              modifier = Modifier.weight(1f)
            )
          }
        }

        Spacer(modifier = Modifier.height(8.dp))
      }

      // REVEAL ANIMATION SUSPENSE OVERLAY
      if (state.isRevealAnimating) {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(MysteryBlack.copy(alpha = 0.92f)),
          contentAlignment = Alignment.Center
        ) {
          Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val infiniteTransition = rememberInfiniteTransition(label = "pulse")
            val scale by infiniteTransition.animateFloat(
              initialValue = 0.88f,
              targetValue = 1.18f,
              animationSpec = infiniteRepeatable(
                animation = tween(400, easing = FastOutSlowInEasing),
                repeatMode = RepeatMode.Reverse
              ),
              label = "scale"
            )

            Box(
              modifier = Modifier
                .size(92.dp)
                .scale(scale)
                .clip(CircleShape)
                .background(ChorRedContainer)
                .border(2.dp, ChorRed, CircleShape),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = ChorRed,
                modifier = Modifier.size(48.dp)
              )
            }

            Spacer(modifier = Modifier.height(20.dp))

            Text(
              text = "UNCOVERING THE CHITS...",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              letterSpacing = 2.sp,
              color = RajaGold
            )
          }
        }
      }
    }
  }

  // REVEAL CONFIRMATION DIALOG
  if (state.showRevealConfirmDialog) {
    AlertDialog(
      onDismissRequest = onDismissRevealDialog,
      containerColor = MysteryDarkSurface,
      titleContentColor = RajaGold,
      textContentColor = TextPrimary,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = RajaGold,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "REVEAL CHOR?",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif
          )
        }
      },
      text = {
        Column {
          Text(
            text = "Are you sure you want to reveal the hidden identity?",
            fontSize = 14.sp,
            lineHeight = 20.sp,
            color = TextSecondary
          )
          if (state.suspectedPlayerId == null) {
            Spacer(modifier = Modifier.height(10.dp))
            Text(
              text = "Note: No suspect has been selected. The Chor will escape and earn +100 points.",
              fontSize = 12.sp,
              color = ChorRed
            )
          }
        }
      },
      confirmButton = {
        TextButton(
          onClick = onExecuteReveal,
          modifier = Modifier.testTag("dialog_reveal_confirm_button")
        ) {
          Text(
            text = "REVEAL",
            color = RajaGold,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = onDismissRevealDialog,
          modifier = Modifier.testTag("dialog_reveal_cancel_button")
        ) {
          Text(
            text = "CANCEL",
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    )
  }
}
