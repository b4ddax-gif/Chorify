package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HowToPlayScreen(
  onBackClick: () -> Unit,
  onStartGameClick: () -> Unit,
  isSoundOn: Boolean,
  onSoundToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = "HOW TO PLAY",
        subtitle = "Rules & Scoring Guide",
        showBack = true,
        isSoundOn = isSoundOn,
        onBackClick = onBackClick,
        onSoundToggle = onSoundToggle
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 520.dp)
          .padding(horizontal = 20.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // THE 4 ROLES EXPLAINED
        Text(
          text = "THE 4 ROLES & VISIBILITY",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        RoleExplanationCard(
          title = "RAJA (King)",
          color = RajaGold,
          icon = Icons.Default.WorkspacePremium,
          visibility = "PUBLIC TO EVERYONE",
          description = "The ruler. Role is revealed immediately to all players. Earns 25 participation points every round."
        )

        Spacer(modifier = Modifier.height(10.dp))

        RoleExplanationCard(
          title = "POLICE (Investigator)",
          color = PoliceBlue,
          icon = Icons.Default.LocalPolice,
          visibility = "PUBLIC TO EVERYONE",
          description = "The enforcer. Role is revealed immediately. Must deduce which of the two secret suspects is the Chor. Earns 100 points for catching the Chor."
        )

        Spacer(modifier = Modifier.height(10.dp))

        RoleExplanationCard(
          title = "MANTRI (Minister)",
          color = MantriGreen,
          icon = Icons.Default.MenuBook,
          visibility = "HIDDEN FROM EVERYONE (EVEN THEMSELVES!)",
          description = "The minister's chit says 'YOUR ROLE IS HIDDEN'. Even the Mantri does not know they are the Mantri! Earns 50 participation points."
        )

        Spacer(modifier = Modifier.height(10.dp))

        RoleExplanationCard(
          title = "CHOR (Thief)",
          color = ChorRed,
          icon = Icons.Default.Lock,
          visibility = "HIDDEN FROM EVERYONE (EVEN THEMSELVES!)",
          description = "The thief's chit also says 'YOUR ROLE IS HIDDEN'. If the Police fails to accuse the Chor (or makes no guess), the Chor escapes and takes 100 points!"
        )

        Spacer(modifier = Modifier.height(24.dp))

        // GAMEPLAY FLOW
        Text(
          text = "STEP-BY-STEP FLOW",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            StepItem(1, "Four players enter their names.")
            StepItem(2, "The game randomly assigns RAJA, POLICE, MANTRI, and CHOR.")
            StepItem(3, "All four player chits appear face-down in their permanent corners on the tabletop board.")
            StepItem(4, "Each player taps their corner chit. RAJA & POLICE are public; MANTRI & CHOR show 'ROLE HIDDEN'.")
            StepItem(5, "Neither Mantri nor Chor knows their own identity! Players debate and deduce.")
            StepItem(6, "Police selects a suspected Chor and confirms their deduction.")
            StepItem(7, "Press the center REVEAL CHOR button to uncover all hidden identities!")
            StepItem(8, "Scores are awarded. Tap NEXT ROUND to reshuffle and continue immediately.")
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // SCORING BREAKDOWN
        Text(
          text = "SCORING BREAKDOWN",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            ScoreRow("Police correctly guesses Chor", "+100 PTS to Police", PoliceBlue)
            ScoreRow("Police guess incorrect / no guess", "+100 PTS to Chor", ChorRed)
            ScoreRow("Mantri participation", "+50 PTS to Mantri", MantriGreen)
            ScoreRow("Raja participation", "+25 PTS to Raja", RajaGold)
          }
        }

        Spacer(modifier = Modifier.height(30.dp))

        ChorifyButton(
          text = "START PLAYING",
          onClick = onStartGameClick,
          style = ButtonStyle.PRIMARY_GOLD,
          testTag = "rules_start_button"
        )

        Spacer(modifier = Modifier.height(32.dp))
      }
    }
  }
}

@Composable
private fun RoleExplanationCard(
  title: String,
  color: Color,
  icon: ImageVector,
  visibility: String,
  description: String
) {
  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(14.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(color.copy(alpha = 0.15f))
            .border(1.dp, color, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(18.dp)
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
          Text(
            text = title,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = color
          )
          Text(
            text = visibility,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.sp
          )
        }
      }
      Spacer(modifier = Modifier.height(8.dp))
      Text(
        text = description,
        fontSize = 13.sp,
        color = TextSecondary,
        lineHeight = 18.sp
      )
    }
  }
}

@Composable
private fun StepItem(number: Int, text: String) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 5.dp),
    verticalAlignment = Alignment.Top
  ) {
    Box(
      modifier = Modifier
        .size(22.dp)
        .clip(CircleShape)
        .background(MysteryElevatedSurface)
        .border(1.dp, RajaGold, CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Text(
        text = "$number",
        fontSize = 11.sp,
        fontWeight = FontWeight.Bold,
        color = RajaGold
      )
    }
    Spacer(modifier = Modifier.width(12.dp))
    Text(
      text = text,
      fontSize = 13.sp,
      color = TextPrimary,
      lineHeight = 18.sp
    )
  }
}

@Composable
private fun ScoreRow(event: String, reward: String, color: Color) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 6.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = event,
      fontSize = 13.sp,
      color = TextSecondary
    )
    Text(
      text = reward,
      fontSize = 13.sp,
      fontWeight = FontWeight.Bold,
      color = color
    )
  }
}
