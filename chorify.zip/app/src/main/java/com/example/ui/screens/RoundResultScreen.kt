package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameState
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.components.RoleBadge
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryBorderActive
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun RoundResultScreen(
  state: GameState,
  onNextRoundClick: () -> Unit,
  onEndGameClick: () -> Unit,
  isSoundOn: Boolean,
  onSoundToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showEndGameConfirmDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = "CHORIFY",
        subtitle = "Round ${state.currentRound} Results",
        showBack = false,
        isSoundOn = isSoundOn,
        onSoundToggle = onSoundToggle
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 520.dp)
          .padding(horizontal = 20.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Emblem
        Box(
          modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(MysteryDarkSurface)
            .border(2.dp, RajaGold, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.EmojiEvents,
            contentDescription = "Round Complete",
            tint = RajaGold,
            modifier = Modifier.size(38.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "ROUND COMPLETE",
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Serif,
          letterSpacing = 2.sp,
          color = RajaGold,
          modifier = Modifier.testTag("round_complete_title")
        )

        Spacer(modifier = Modifier.height(6.dp))

        // Police Guess recap
        val result = state.lastGuessResult
        val recapText = when {
          result?.isCorrect == true -> "Police deduced correctly! Caught the Chor (+100 PTS)"
          result?.suspectedPlayerName != null -> "Police accused ${result.suspectedPlayerName}. Chor escaped! (+100 PTS)"
          else -> "Police did not submit a guess. Chor escaped! (+100 PTS)"
        }

        Text(
          text = recapText,
          fontSize = 13.sp,
          color = TextSecondary,
          textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        // TABLE: PLAYER | ROLE | ROUND SCORE | TOTAL SCORE
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier
            .fillMaxWidth()
            .testTag("round_result_table")
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(14.dp)) {
            // Table Header
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 6.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "PLAYER",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.weight(1.3f)
              )
              Text(
                text = "ROLE",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                modifier = Modifier.weight(1.2f)
              )
              Text(
                text = "ROUND",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
              )
              Text(
                text = "TOTAL",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextMuted,
                letterSpacing = 1.sp,
                textAlign = TextAlign.End,
                modifier = Modifier.weight(0.9f)
              )
            }

            HorizontalDivider(
              thickness = 1.dp,
              color = MysteryBorderActive.copy(alpha = 0.5f),
              modifier = Modifier.padding(vertical = 4.dp)
            )

            // Table Rows
            state.players.forEach { player ->
              RoundResultTableRow(player = player)
              HorizontalDivider(
                thickness = 0.5.dp,
                color = MysteryBorder.copy(alpha = 0.4f),
                modifier = Modifier.padding(vertical = 4.dp)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(30.dp))

        // BUTTONS: NEXT ROUND & END GAME
        ChorifyButton(
          text = "NEXT ROUND",
          onClick = onNextRoundClick,
          style = ButtonStyle.PRIMARY_GOLD,
          testTag = "result_next_round_button"
        )

        Spacer(modifier = Modifier.height(14.dp))

        ChorifyButton(
          text = "END GAME",
          onClick = { showEndGameConfirmDialog = true },
          style = ButtonStyle.SECONDARY_OUTLINE,
          testTag = "result_end_game_button"
        )

        Spacer(modifier = Modifier.height(32.dp))
      }
    }
  }

  if (showEndGameConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showEndGameConfirmDialog = false },
      containerColor = MysteryDarkSurface,
      titleContentColor = RajaGold,
      textContentColor = TextPrimary,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = RajaGold,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "END CURRENT GAME?",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif
          )
        }
      },
      text = {
        Text(
          text = "This will conclude the match and display the final leaderboard standings.",
          fontSize = 14.sp,
          color = TextSecondary
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            showEndGameConfirmDialog = false
            onEndGameClick()
          },
          modifier = Modifier.testTag("dialog_end_game_confirm_button")
        ) {
          Text(
            text = "END MATCH",
            color = RajaGold,
            fontWeight = FontWeight.Bold
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showEndGameConfirmDialog = false },
          modifier = Modifier.testTag("dialog_end_game_cancel_button")
        ) {
          Text(
            text = "CONTINUE PLAYING",
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    )
  }
}

@Composable
private fun RoundResultTableRow(player: Player) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 6.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      text = player.name,
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
      color = TextPrimary,
      modifier = Modifier.weight(1.3f)
    )

    Box(modifier = Modifier.weight(1.2f)) {
      RoleBadge(
        role = player.currentRole,
        isExplicitlyRevealed = true,
        showLabel = true
      )
    }

    Text(
      text = "+${player.roundScore}",
      fontSize = 14.sp,
      fontWeight = FontWeight.Bold,
      color = if (player.roundScore > 0) RajaGold else TextSecondary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.9f)
    )

    Text(
      text = "${player.totalScore}",
      fontSize = 15.sp,
      fontWeight = FontWeight.Bold,
      color = TextPrimary,
      textAlign = TextAlign.End,
      modifier = Modifier.weight(0.9f)
    )
  }
}
