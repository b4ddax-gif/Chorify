package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Background & Surface
val MysteryBlack = Color(0xFF090B0E)
val MysteryDarkSurface = Color(0xFF131720)
val MysteryElevatedSurface = Color(0xFF1B202D)
val MysteryBorder = Color(0xFF2B3245)
val MysteryBorderActive = Color(0xFF4A5568)

// Role Specific Colors
// Raja (King) - Opulent Royal Gold
val RajaGold = Color(0xFFFFD166)
val RajaGoldDark = Color(0xFFB8860B)
val RajaGoldContainer = Color(0xFF33290A)

// Police - Royal Blue / Law Enforcement
val PoliceBlue = Color(0xFF38BDF8)
val PoliceBlueDark = Color(0xFF0284C7)
val PoliceBlueContainer = Color(0xFF0C2A44)

// Chor (Thief) - Deep Crimson / Mystery Red
val ChorRed = Color(0xFFEF4444)
val ChorRedDark = Color(0xFFB91C1C)
val ChorRedContainer = Color(0xFF3B1214)

// Mantri (Minister) - Royal Emerald / Sage Wisdom
val MantriGreen = Color(0xFF10B981)
val MantriGreenDark = Color(0xFF047857)
val MantriGreenContainer = Color(0xFF0B2E21)

// Hidden / Neutral
val HiddenRoleGray = Color(0xFF94A3B8)
val HiddenRoleDark = Color(0xFF334155)
val HiddenRoleContainer = Color(0xFF1E293B)

// Accents & Texts
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

val AccentGold = Color(0xFFF59E0B)
val SuccessGreen = Color(0xFF10B981)
