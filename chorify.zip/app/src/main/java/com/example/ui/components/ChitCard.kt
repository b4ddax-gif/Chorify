package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.ui.theme.HiddenRoleContainer
import com.example.ui.theme.HiddenRoleGray
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueContainer
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ChitCard(
  player: Player,
  modifier: Modifier = Modifier
) {
  var flipped by remember { mutableStateOf(false) }

  LaunchedEffect(player.id) {
    flipped = true
  }

  val rotationY by animateFloatAsState(
    targetValue = if (flipped) 0f else 90f,
    animationSpec = tween(durationMillis = 400, easing = FastOutSlowInEasing),
    label = "chit_flip"
  )

  val role = player.currentRole

  // STRICT ROLE VISIBILITY RULES:
  // RAJA: "RAJA" and "Everyone can see this role."
  // POLICE: "POLICE" and "Everyone can see this role."
  // MANTRI: DO NOT display MANTRI. Display only: "YOUR ROLE IS HIDDEN"
  // CHOR: DO NOT display CHOR. Display only: "YOUR ROLE IS HIDDEN"
  val isRaja = role == Role.RAJA
  val isPolice = role == Role.POLICE
  val isHidden = role == Role.MANTRI || role == Role.CHOR

  val title = when {
    isRaja -> "RAJA"
    isPolice -> "POLICE"
    isHidden -> "YOUR ROLE IS HIDDEN"
    else -> "UNKNOWN"
  }

  val subtitle = when {
    isRaja || isPolice -> "Everyone can see this role."
    isHidden -> "You are one of the secret suspects. Bluff, defend, and stay vigilant!"
    else -> ""
  }

  val accentColor = when {
    isRaja -> RajaGold
    isPolice -> PoliceBlue
    else -> HiddenRoleGray
  }

  val cardBg = when {
    isRaja -> RajaGoldContainer
    isPolice -> PoliceBlueContainer
    else -> HiddenRoleContainer
  }

  val icon = when {
    isRaja -> Icons.Default.WorkspacePremium
    isPolice -> Icons.Default.LocalPolice
    else -> Icons.Default.VisibilityOff
  }

  Card(
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(containerColor = cardBg),
    border = androidx.compose.foundation.BorderStroke(1.5.dp, accentColor),
    modifier = modifier
      .fillMaxWidth()
      .graphicsLayer {
        this.rotationY = rotationY
        cameraDistance = 12f * density
      }
      .testTag("secret_chit_card")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp, vertical = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      // Paper fold / Wax seal badge
      Box(
        modifier = Modifier
          .size(80.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.15f))
          .border(2.dp, accentColor, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = icon,
          contentDescription = title,
          tint = accentColor,
          modifier = Modifier.size(44.dp)
        )
      }

      Spacer(modifier = Modifier.height(24.dp))

      Text(
        text = player.name,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 2.sp,
        color = TextSecondary
      )

      Spacer(modifier = Modifier.height(10.dp))

      Text(
        text = title,
        fontSize = if (isHidden) 22.sp else 32.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Serif,
        color = accentColor,
        textAlign = TextAlign.Center,
        letterSpacing = if (isHidden) 1.5.sp else 3.sp,
        modifier = Modifier.testTag("chit_role_title")
      )

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text = subtitle,
        fontSize = 14.sp,
        color = TextPrimary.copy(alpha = 0.85f),
        textAlign = TextAlign.Center,
        lineHeight = 20.sp,
        modifier = Modifier.testTag("chit_role_subtitle")
      )

      if (isHidden) {
        Spacer(modifier = Modifier.height(20.dp))
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MysteryDarkSurface)
            .border(1.dp, MysteryBorder, RoundedCornerShape(10.dp))
            .padding(12.dp)
        ) {
          Text(
            text = "Neither you nor the others know whether you are Mantri or Chor until the final reveal!",
            fontSize = 12.sp,
            color = HiddenRoleGray,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth()
          )
        }
      }
    }
  }
}
