package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Screen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.HowToPlayScreen
import com.example.ui.screens.MainGameScreen
import com.example.ui.screens.RoundResultScreen
import com.example.ui.screens.ScoreboardScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.SetupScreen
import com.example.ui.theme.MysteryBlack

@Composable
fun ChorifyApp(
  viewModel: GameViewModel,
  modifier: Modifier = Modifier
) {
  val state by viewModel.state.collectAsStateWithLifecycle()
  val isSoundOn by viewModel.isSoundOn.collectAsStateWithLifecycle()
  val isVibrationOn by viewModel.isVibrationOn.collectAsStateWithLifecycle()

  // Android Back Button handler
  BackHandler(enabled = state.currentScreen != Screen.HOME) {
    viewModel.handleBack()
  }

  Surface(
    modifier = modifier.fillMaxSize(),
    color = MysteryBlack
  ) {
    AnimatedContent(
      targetState = state.currentScreen,
      transitionSpec = { fadeIn() togetherWith fadeOut() },
      label = "screen_transition"
    ) { screen ->
      when (screen) {
        Screen.HOME -> {
          HomeScreen(
            onNewGameClick = { viewModel.navigateTo(Screen.PLAYER_SETUP) },
            onHowToPlayClick = { viewModel.navigateTo(Screen.HOW_TO_PLAY) },
            onSettingsClick = { viewModel.navigateTo(Screen.SETTINGS) },
            onScoreboardClick = { viewModel.navigateTo(Screen.SCOREBOARD) }
          )
        }

        Screen.PLAYER_SETUP -> {
          SetupScreen(
            players = state.players,
            onUpdatePlayerName = { index, name -> viewModel.updatePlayerName(index, name) },
            onStartGameClick = { viewModel.startNewGameSession() },
            onBackClick = { viewModel.handleBack() },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }

        Screen.MAIN_GAME -> {
          MainGameScreen(
            state = state,
            onTapChit = { playerId -> viewModel.tapPlayerChit(playerId) },
            onSelectSuspect = { playerId -> viewModel.selectSuspect(playerId) },
            onConfirmGuess = { viewModel.confirmGuess() },
            onRequestReveal = { viewModel.requestReveal() },
            onDismissRevealDialog = { viewModel.dismissRevealDialog() },
            onExecuteReveal = { viewModel.executeReveal() },
            onStartNextRound = { viewModel.startNextRound() },
            onProceedToRoundResult = { viewModel.proceedToRoundResult() },
            onScoreboardClick = { viewModel.navigateTo(Screen.SCOREBOARD) },
            onSettingsClick = { viewModel.navigateTo(Screen.SETTINGS) },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }

        Screen.ROUND_RESULT -> {
          RoundResultScreen(
            state = state,
            onNextRoundClick = { viewModel.startNextRound() },
            onEndGameClick = { viewModel.endGame() },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }

        Screen.SCOREBOARD -> {
          ScoreboardScreen(
            state = state,
            isFinalMatchScoreboard = false,
            onBackClick = { viewModel.handleBack() },
            onHomeClick = { viewModel.navigateTo(Screen.HOME) },
            onStartNewGameClick = { viewModel.navigateTo(Screen.PLAYER_SETUP) },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }

        Screen.FINAL_SCOREBOARD -> {
          ScoreboardScreen(
            state = state,
            isFinalMatchScoreboard = true,
            onBackClick = { viewModel.navigateTo(Screen.HOME) },
            onHomeClick = { viewModel.navigateTo(Screen.HOME) },
            onStartNewGameClick = { viewModel.navigateTo(Screen.PLAYER_SETUP) },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }

        Screen.SETTINGS -> {
          SettingsScreen(
            isSoundOn = isSoundOn,
            isVibrationOn = isVibrationOn,
            onToggleSound = { viewModel.toggleSound() },
            onToggleVibration = { viewModel.toggleVibration() },
            onResetScoresClick = { viewModel.resetScores() },
            onNewGameClick = { viewModel.navigateTo(Screen.PLAYER_SETUP) },
            onBackClick = { viewModel.handleBack() }
          )
        }

        Screen.HOW_TO_PLAY -> {
          HowToPlayScreen(
            onBackClick = { viewModel.handleBack() },
            onStartGameClick = { viewModel.navigateTo(Screen.PLAYER_SETUP) },
            isSoundOn = isSoundOn,
            onSoundToggle = { viewModel.toggleSound() }
          )
        }
      }
    }
  }
}
