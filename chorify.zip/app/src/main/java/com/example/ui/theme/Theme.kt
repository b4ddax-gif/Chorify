package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
  primary = RajaGold,
  onPrimary = MysteryBlack,
  primaryContainer = RajaGoldContainer,
  onPrimaryContainer = RajaGold,

  secondary = PoliceBlue,
  onSecondary = MysteryBlack,
  secondaryContainer = PoliceBlueContainer,
  onSecondaryContainer = PoliceBlue,

  tertiary = ChorRed,
  onTertiary = TextPrimary,
  tertiaryContainer = ChorRedContainer,
  onTertiaryContainer = ChorRed,

  background = MysteryBlack,
  onBackground = TextPrimary,
  surface = MysteryDarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = MysteryElevatedSurface,
  onSurfaceVariant = TextSecondary,

  outline = MysteryBorder,
  outlineVariant = MysteryBorderActive,
  error = ChorRed,
  onError = TextPrimary
)

@Composable
fun ChorifyTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = DarkColorScheme,
    typography = Typography,
    content = content
  )
}
