package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
  isSoundOn: Boolean,
  isVibrationOn: Boolean,
  onToggleSound: () -> Unit,
  onToggleVibration: () -> Unit,
  onResetScoresClick: () -> Unit,
  onNewGameClick: () -> Unit,
  onBackClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  var showResetConfirmDialog by remember { mutableStateOf(false) }

  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = "SETTINGS",
        subtitle = "Game Preferences",
        showBack = true,
        isSoundOn = isSoundOn,
        onBackClick = onBackClick
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 500.dp)
          .padding(horizontal = 20.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Audio & Tactile Preferences Card
        Text(
          text = "EXPERIENCE & AUDIO",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            // Sound Effects Toggle
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(MysteryElevatedSurface),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.VolumeUp,
                  contentDescription = "Sound",
                  tint = RajaGold,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Sound Effects",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = "Chit flip, suspense & fanfare sounds",
                  fontSize = 12.sp,
                  color = TextSecondary
                )
              }
              Switch(
                checked = isSoundOn,
                onCheckedChange = { onToggleSound() },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = RajaGold,
                  checkedTrackColor = RajaGold.copy(alpha = 0.35f),
                  uncheckedThumbColor = TextMuted,
                  uncheckedTrackColor = MysteryElevatedSurface
                ),
                modifier = Modifier.testTag("settings_sound_switch")
              )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Vibration Toggle
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Box(
                modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(MysteryElevatedSurface),
                contentAlignment = Alignment.Center
              ) {
                Icon(
                  imageVector = Icons.Default.Vibration,
                  contentDescription = "Vibration",
                  tint = RajaGold,
                  modifier = Modifier.size(20.dp)
                )
              }
              Spacer(modifier = Modifier.width(14.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Haptic Vibration",
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Bold,
                  color = TextPrimary
                )
                Text(
                  text = "Tactile feedback on chit & reveals",
                  fontSize = 12.sp,
                  color = TextSecondary
                )
              }
              Switch(
                checked = isVibrationOn,
                onCheckedChange = { onToggleVibration() },
                colors = SwitchDefaults.colors(
                  checkedThumbColor = RajaGold,
                  checkedTrackColor = RajaGold.copy(alpha = 0.35f),
                  uncheckedThumbColor = TextMuted,
                  uncheckedTrackColor = MysteryElevatedSurface
                ),
                modifier = Modifier.testTag("settings_vibration_switch")
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // THEME & DISPLAY
        Text(
          text = "THEME",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Box(
              modifier = Modifier
                .size(38.dp)
                .clip(CircleShape)
                .background(MysteryElevatedSurface),
              contentAlignment = Alignment.Center
            ) {
              Icon(
                imageVector = Icons.Default.DarkMode,
                contentDescription = "Theme",
                tint = RajaGold,
                modifier = Modifier.size(20.dp)
              )
            }
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Premium Mystery Dark",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )
              Text(
                text = "Optimized for OLED & secrecy in low light",
                fontSize = 12.sp,
                color = TextSecondary
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // GAME CONTROLS
        Text(
          text = "MATCH CONTROLS",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TextMuted,
          letterSpacing = 1.5.sp,
          modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(10.dp))

        ChorifyButton(
          text = "START NEW GAME",
          onClick = onNewGameClick,
          style = ButtonStyle.SURFACE_ELEVATED,
          testTag = "settings_new_game_button"
        )

        Spacer(modifier = Modifier.height(12.dp))

        ChorifyButton(
          text = "RESET SCORES",
          onClick = { showResetConfirmDialog = true },
          style = ButtonStyle.SECONDARY_OUTLINE,
          testTag = "settings_reset_scores_button"
        )

        Spacer(modifier = Modifier.height(28.dp))

        // Offline and Privacy notice
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
          modifier = Modifier.fillMaxWidth()
        ) {
          Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              imageVector = Icons.Default.Info,
              contentDescription = null,
              tint = RajaGold,
              modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = "CHORIFY operates 100% locally. Zero tracking, zero telemetry, no internet required.",
              fontSize = 12.sp,
              color = TextSecondary,
              lineHeight = 16.sp
            )
          }
        }

        Spacer(modifier = Modifier.height(32.dp))
      }
    }
  }

  if (showResetConfirmDialog) {
    AlertDialog(
      onDismissRequest = { showResetConfirmDialog = false },
      containerColor = MysteryDarkSurface,
      titleContentColor = RajaGold,
      textContentColor = TextPrimary,
      title = {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
            imageVector = Icons.Default.Warning,
            contentDescription = null,
            tint = ChorRed,
            modifier = Modifier.size(24.dp)
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "RESET SCORES?",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif
          )
        }
      },
      text = {
        Text(
          text = "This will reset all accumulated points for current players to zero.",
          fontSize = 14.sp,
          color = TextSecondary
        )
      },
      confirmButton = {
        TextButton(
          onClick = {
            showResetConfirmDialog = false
            onResetScoresClick()
          },
          modifier = Modifier.testTag("dialog_reset_confirm_button")
        ) {
          Text(
            text = "RESET",
            color = ChorRed,
            fontWeight = FontWeight.Bold
          )
        }
      },
      dismissButton = {
        TextButton(
          onClick = { showResetConfirmDialog = false },
          modifier = Modifier.testTag("dialog_reset_cancel_button")
        ) {
          Text(
            text = "CANCEL",
            color = TextSecondary,
            fontWeight = FontWeight.SemiBold
          )
        }
      }
    )
  }
}
