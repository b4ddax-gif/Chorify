package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.ui.theme.ChorRed
import com.example.ui.theme.ChorRedContainer
import com.example.ui.theme.HiddenRoleContainer
import com.example.ui.theme.HiddenRoleGray
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MantriGreenContainer
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryBorderActive
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueContainer
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SuspectCard(
  player: Player,
  isSelected: Boolean,
  isChorRevealed: Boolean,
  isGuessConfirmed: Boolean,
  onSelect: () -> Unit,
  modifier: Modifier = Modifier
) {
  val role = player.currentRole

  // Strictly enforce visibility:
  // Before final reveal: ONLY Raja and Police are shown.
  // Mantri and Chor are shown as HIDDEN ROLE!
  val showRoleExplicitly = isChorRevealed || role == Role.RAJA || role == Role.POLICE

  val roleLabel = when {
    !showRoleExplicitly -> "HIDDEN ROLE"
    role == Role.RAJA -> "RAJA"
    role == Role.POLICE -> "POLICE"
    role == Role.MANTRI -> "MANTRI"
    role == Role.CHOR -> "CHOR"
    else -> "UNKNOWN"
  }

  val roleColor = when {
    !showRoleExplicitly -> HiddenRoleGray
    role == Role.RAJA -> RajaGold
    role == Role.POLICE -> PoliceBlue
    role == Role.MANTRI -> MantriGreen
    role == Role.CHOR -> ChorRed
    else -> HiddenRoleGray
  }

  val containerColor = when {
    !showRoleExplicitly && isSelected -> ChorRedContainer.copy(alpha = 0.5f)
    !showRoleExplicitly -> MysteryElevatedSurface
    role == Role.RAJA -> RajaGoldContainer.copy(alpha = 0.4f)
    role == Role.POLICE -> PoliceBlueContainer.copy(alpha = 0.4f)
    role == Role.MANTRI -> MantriGreenContainer.copy(alpha = 0.5f)
    role == Role.CHOR -> ChorRedContainer.copy(alpha = 0.7f)
    else -> MysteryElevatedSurface
  }

  val borderColor by animateColorAsState(
    targetValue = when {
      isSelected && isGuessConfirmed -> ChorRed
      isSelected -> ChorRed.copy(alpha = 0.8f)
      role == Role.RAJA -> RajaGold.copy(alpha = 0.6f)
      role == Role.POLICE -> PoliceBlue.copy(alpha = 0.6f)
      isChorRevealed && role == Role.CHOR -> ChorRed
      isChorRevealed && role == Role.MANTRI -> MantriGreen
      else -> MysteryBorder
    },
    label = "card_border"
  )

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(
      width = if (isSelected || isChorRevealed) 2.dp else 1.dp,
      color = borderColor
    ),
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable(enabled = !isChorRevealed) { onSelect() }
      .testTag("suspect_card_${player.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Role Icon
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(roleColor.copy(alpha = 0.15f))
          .border(1.5.dp, roleColor.copy(alpha = 0.6f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        val icon = when {
          !showRoleExplicitly -> Icons.Default.VisibilityOff
          role == Role.RAJA -> Icons.Default.WorkspacePremium
          role == Role.POLICE -> Icons.Default.LocalPolice
          role == Role.MANTRI -> Icons.Default.MenuBook
          role == Role.CHOR -> Icons.Default.Lock
          else -> Icons.Default.HelpOutline
        }
        Icon(
          imageVector = icon,
          contentDescription = roleLabel,
          tint = roleColor,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = player.name,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Spacer(modifier = Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = roleLabel,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = roleColor,
            letterSpacing = 1.sp
          )
          if (isSelected) {
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (isGuessConfirmed) "• GUESS CONFIRMED" else "• SUSPECTED",
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              color = ChorRed
            )
          }
        }
      }

      // Selection or Status indicator
      if (!isChorRevealed) {
        Box(
          modifier = Modifier
            .size(32.dp)
            .clip(CircleShape)
            .background(if (isSelected) ChorRed else Color.Transparent)
            .border(
              1.5.dp,
              if (isSelected) ChorRed else MysteryBorderActive,
              CircleShape
            ),
          contentAlignment = Alignment.Center
        ) {
          if (isSelected) {
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Selected",
              tint = TextPrimary,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      } else {
        // Show points earned badge
        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(roleColor.copy(alpha = 0.2f))
            .border(1.dp, roleColor, RoundedCornerShape(8.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(
            text = "+${player.roundScore} PTS",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = roleColor
          )
        }
      }
    }
  }
}
