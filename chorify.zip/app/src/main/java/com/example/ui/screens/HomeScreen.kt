package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Screen
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.theme.ChorRed
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun HomeScreen(
  onNewGameClick: () -> Unit,
  onHowToPlayClick: () -> Unit,
  onSettingsClick: () -> Unit,
  onScoreboardClick: () -> Unit,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(MysteryBlack)
      .statusBarsPadding()
      .navigationBarsPadding(),
    contentAlignment = Alignment.Center
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .widthIn(max = 500.dp)
        .padding(horizontal = 24.dp)
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      // Royal Mystery Emblem
      Box(
        modifier = Modifier
          .size(100.dp)
          .clip(CircleShape)
          .background(MysteryDarkSurface)
          .border(2.dp, RajaGold, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(
          imageVector = Icons.Default.WorkspacePremium,
          contentDescription = "Chorify Crown",
          tint = RajaGold,
          modifier = Modifier.size(54.dp)
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      // App Title
      Text(
        text = "CHORIFY",
        fontSize = 38.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Serif,
        color = RajaGold,
        letterSpacing = 4.sp,
        textAlign = TextAlign.Center,
        modifier = Modifier.testTag("home_title")
      )

      Spacer(modifier = Modifier.height(8.dp))

      // App Subtitle / Badge
      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(MysteryElevatedSurface)
          .border(1.dp, MysteryBorder, RoundedCornerShape(20.dp))
          .padding(horizontal = 16.dp, vertical = 6.dp)
      ) {
        Text(
          text = "4 PLAYERS • OFFLINE",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TextSecondary,
          letterSpacing = 1.5.sp,
          modifier = Modifier.testTag("home_subtitle")
        )
      }

      Spacer(modifier = Modifier.height(28.dp))

      // Core Roles Preview Strip
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp, horizontal = 8.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically
        ) {
          RolePreviewItem(name = "RAJA", color = RajaGold, icon = Icons.Default.WorkspacePremium)
          RolePreviewItem(name = "MANTRI", color = MantriGreen, icon = Icons.Default.VisibilityOff)
          RolePreviewItem(name = "CHOR", color = ChorRed, icon = Icons.Default.Lock)
          RolePreviewItem(name = "POLICE", color = PoliceBlue, icon = Icons.Default.Security)
        }
      }

      Spacer(modifier = Modifier.height(32.dp))

      // Action Buttons
      ChorifyButton(
        text = "NEW GAME",
        onClick = onNewGameClick,
        style = ButtonStyle.PRIMARY_GOLD,
        testTag = "home_new_game_button"
      )

      Spacer(modifier = Modifier.height(14.dp))

      ChorifyButton(
        text = "HOW TO PLAY",
        onClick = onHowToPlayClick,
        style = ButtonStyle.SURFACE_ELEVATED,
        testTag = "home_how_to_play_button"
      )

      Spacer(modifier = Modifier.height(14.dp))

      ChorifyButton(
        text = "SCOREBOARD",
        onClick = onScoreboardClick,
        style = ButtonStyle.SURFACE_ELEVATED,
        testTag = "home_scoreboard_button"
      )

      Spacer(modifier = Modifier.height(14.dp))

      ChorifyButton(
        text = "SETTINGS",
        onClick = onSettingsClick,
        style = ButtonStyle.SECONDARY_OUTLINE,
        testTag = "home_settings_button"
      )

      Spacer(modifier = Modifier.height(32.dp))

      Text(
        text = "Pure Offline Same-Device Deduction",
        fontSize = 12.sp,
        color = TextMuted,
        letterSpacing = 0.5.sp
      )

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}

@Composable
private fun RolePreviewItem(
  name: String,
  color: Color,
  icon: androidx.compose.ui.graphics.vector.ImageVector
) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Box(
      modifier = Modifier
        .size(36.dp)
        .clip(CircleShape)
        .background(color.copy(alpha = 0.15f))
        .border(1.dp, color.copy(alpha = 0.5f), CircleShape),
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = icon,
        contentDescription = name,
        tint = color,
        modifier = Modifier.size(18.dp)
      )
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      text = name,
      fontSize = 10.sp,
      fontWeight = FontWeight.Bold,
      color = color,
      letterSpacing = 0.75.sp
    )
  }
}
