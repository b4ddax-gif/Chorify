package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.PreferencesManager
import com.example.data.model.GameState
import com.example.data.model.GuessResult
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.data.model.RoundHistoryItem
import com.example.data.model.Screen
import com.example.util.SoundManager
import com.example.util.VibrationHelper
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class GameViewModel(application: Application) : AndroidViewModel(application) {
  val prefs = PreferencesManager(application)
  val sounds = SoundManager(isSoundEnabled = { prefs.isSoundEnabled })
  val haptics = VibrationHelper(application, isVibrationEnabled = { prefs.isVibrationEnabled })

  private val _state = MutableStateFlow(
    GameState(
      players = listOf(
        Player(id = 1, name = prefs.getPlayerName(1, "PLAYER 1")),
        Player(id = 2, name = prefs.getPlayerName(2, "PLAYER 2")),
        Player(id = 3, name = prefs.getPlayerName(3, "PLAYER 3")),
        Player(id = 4, name = prefs.getPlayerName(4, "PLAYER 4"))
      )
    )
  )
  val state: StateFlow<GameState> = _state.asStateFlow()

  private val _isSoundOn = MutableStateFlow(prefs.isSoundEnabled)
  val isSoundOn: StateFlow<Boolean> = _isSoundOn.asStateFlow()

  private val _isVibrationOn = MutableStateFlow(prefs.isVibrationEnabled)
  val isVibrationOn: StateFlow<Boolean> = _isVibrationOn.asStateFlow()

  fun navigateTo(screen: Screen) {
    sounds.playButtonClick()
    haptics.vibrateClick()
    _state.update { current ->
      current.copy(
        previousScreen = current.currentScreen,
        currentScreen = screen
      )
    }
  }

  fun handleBack(): Boolean {
    val current = _state.value.currentScreen
    return when (current) {
      Screen.HOME -> false // Exit app
      Screen.HOW_TO_PLAY, Screen.SETTINGS, Screen.SCOREBOARD -> {
        navigateTo(_state.value.previousScreen.takeIf { it != current } ?: Screen.HOME)
        true
      }
      Screen.PLAYER_SETUP -> {
        navigateTo(Screen.HOME)
        true
      }
      Screen.MAIN_GAME -> {
        navigateTo(Screen.HOME)
        true
      }
      Screen.ROUND_RESULT -> {
        navigateTo(Screen.HOME)
        true
      }
      Screen.FINAL_SCOREBOARD -> {
        navigateTo(Screen.HOME)
        true
      }
    }
  }

  fun updatePlayerName(index: Int, newName: String) {
    _state.update { current ->
      val updatedList = current.players.toMutableList()
      if (index in updatedList.indices) {
        updatedList[index] = updatedList[index].copy(name = newName)
        prefs.savePlayerName(index + 1, newName)
      }
      current.copy(players = updatedList)
    }
  }

  fun arePlayerNamesValid(): Boolean {
    val players = _state.value.players
    return players.size == 4 && players.all { it.name.trim().isNotEmpty() }
  }

  /**
   * Starts a brand new game match on the 4-corner board.
   * Immediately assigns roles and places all 4 chits face-down on the board.
   * No sequential pass-phone screens.
   */
  fun startNewGameSession() {
    sounds.playChitShuffle()
    haptics.vibrateConfirm()

    val shuffledRoles = Role.createShuffledRoles()
    _state.update { current ->
      val updatedPlayers = current.players.mapIndexed { index, player ->
        player.copy(
          currentRole = shuffledRoles[index],
          isChitTapped = false,
          totalScore = 0,
          roundScore = 0
        )
      }
      current.copy(
        players = updatedPlayers,
        currentRound = 1,
        suspectedPlayerId = null,
        isGuessConfirmed = false,
        isChorRevealed = false,
        hasScoredCurrentRound = false,
        lastGuessResult = null,
        roundHistory = emptyList(),
        showRevealConfirmDialog = false,
        isRevealAnimating = false,
        currentScreen = Screen.MAIN_GAME
      )
    }
  }

  /**
   * Player taps their chit in their corner.
   * If face-down, it is tapped/flipped.
   * Note: The UI layer strictly handles hiding MANTRI and CHOR ("ROLE HIDDEN").
   */
  fun tapPlayerChit(playerId: Int) {
    if (_state.value.isChorRevealed) return // Round is completed

    val player = _state.value.players.firstOrNull { it.id == playerId } ?: return
    if (!player.isChitTapped) {
      sounds.playChitFlip()
      haptics.vibrateChit()
      _state.update { current ->
        val updated = current.players.map {
          if (it.id == playerId) it.copy(isChitTapped = true) else it
        }
        current.copy(players = updated)
      }
    }
  }

  /**
   * Police suspects a player.
   */
  fun selectSuspect(playerId: Int) {
    if (_state.value.isChorRevealed) return
    sounds.playButtonClick()
    haptics.vibrateClick()
    _state.update { it.copy(suspectedPlayerId = playerId) }
  }

  fun confirmGuess() {
    if (_state.value.suspectedPlayerId == null) return
    sounds.playButtonClick()
    haptics.vibrateConfirm()
    _state.update { it.copy(isGuessConfirmed = true) }
  }

  fun requestReveal() {
    sounds.playButtonClick()
    haptics.vibrateClick()
    _state.update { it.copy(showRevealConfirmDialog = true) }
  }

  fun dismissRevealDialog() {
    sounds.playButtonClick()
    haptics.vibrateClick()
    _state.update { it.copy(showRevealConfirmDialog = false) }
  }

  /**
   * Executes the REVEAL CHOR action.
   * - Shows animation
   * - Reveals actual CHOR and MANTRI
   * - Reveals all 4 roles on board
   * - Locks further chit interaction
   * - Calculates scores (preventing duplicates)
   */
  fun executeReveal() {
    sounds.playSuspenseDrone()
    haptics.vibrateReveal()

    _state.update { it.copy(showRevealConfirmDialog = false, isRevealAnimating = true) }

    viewModelScope.launch {
      delay(900) // Brief dramatic suspense animation duration

      val current = _state.value
      if (current.hasScoredCurrentRound) {
        _state.update { it.copy(isRevealAnimating = false, isChorRevealed = true) }
        return@launch
      }

      val chor = current.chorPlayer ?: return@launch
      val police = current.policePlayer ?: return@launch
      val mantri = current.mantriPlayer ?: return@launch
      val raja = current.rajaPlayer ?: return@launch

      val suspectedId = current.suspectedPlayerId
      val isPoliceCorrect = suspectedId != null && suspectedId == chor.id

      // Scoring Breakdown:
      // Police correct: Police +100
      // Police wrong or no guess: Chor +100
      // Mantri: +50 participation points
      // Raja: +25 participation points
      val policePts = if (isPoliceCorrect) 100 else 0
      val chorPts = if (isPoliceCorrect) 0 else 100
      val mantriPts = 50
      val rajaPts = 25

      val suspectedPlayer = current.players.firstOrNull { it.id == suspectedId }

      val guessResult = GuessResult(
        suspectedPlayerId = suspectedId,
        suspectedPlayerName = suspectedPlayer?.name,
        isCorrect = isPoliceCorrect,
        actualChorPlayer = chor,
        actualMantriPlayer = mantri,
        pointsAwardedPolice = policePts,
        pointsAwardedChor = chorPts,
        pointsAwardedMantri = mantriPts,
        pointsAwardedRaja = rajaPts
      )

      val updatedPlayers = current.players.map { p ->
        val roundPts = when (p.currentRole) {
          Role.POLICE -> policePts
          Role.CHOR -> chorPts
          Role.MANTRI -> mantriPts
          Role.RAJA -> rajaPts
          null -> 0
        }
        p.copy(
          isChitTapped = true, // all revealed at round completion
          roundScore = roundPts,
          totalScore = p.totalScore + roundPts
        )
      }

      val historyItem = RoundHistoryItem(
        roundNumber = current.currentRound,
        rajaName = raja.name,
        policeName = police.name,
        chorName = chor.name,
        mantriName = mantri.name,
        suspectedName = suspectedPlayer?.name,
        policeWon = isPoliceCorrect
      )

      sounds.playReveal(isPoliceCorrect)

      _state.update {
        it.copy(
          players = updatedPlayers,
          isChorRevealed = true,
          isRevealAnimating = false,
          hasScoredCurrentRound = true,
          lastGuessResult = guessResult,
          roundHistory = it.roundHistory + historyItem
        )
      }
    }
  }

  fun proceedToRoundResult() {
    sounds.playButtonClick()
    haptics.vibrateClick()
    _state.update { it.copy(currentScreen = Screen.ROUND_RESULT) }
  }

  /**
   * Starts next round immediately on the 4-corner board:
   * - Keep player names
   * - Keep cumulative scores
   * - Generate a new random role assignment (independently randomized)
   * - Reset all four chits to face-down (isChitTapped = false)
   * - Place them again in the same four corners
   * - Start the new round immediately (Screen.MAIN_GAME)
   */
  fun startNextRound() {
    sounds.playChitShuffle()
    haptics.vibrateConfirm()

    val current = _state.value
    val previousRoles = current.players.mapNotNull { it.currentRole }
    val newRoles = Role.createShuffledRoles(previousRoles)

    val updatedPlayers = current.players.mapIndexed { index, player ->
      player.copy(
        currentRole = newRoles[index],
        isChitTapped = false,
        roundScore = 0
      )
    }

    _state.update {
      it.copy(
        players = updatedPlayers,
        currentRound = it.currentRound + 1,
        suspectedPlayerId = null,
        isGuessConfirmed = false,
        isChorRevealed = false,
        hasScoredCurrentRound = false,
        lastGuessResult = null,
        showRevealConfirmDialog = false,
        isRevealAnimating = false,
        currentScreen = Screen.MAIN_GAME
      )
    }
  }

  fun endGame() {
    sounds.playButtonClick()
    haptics.vibrateConfirm()
    _state.update { it.copy(currentScreen = Screen.FINAL_SCOREBOARD) }
  }

  fun resetScores() {
    sounds.playButtonClick()
    haptics.vibrateConfirm()
    _state.update { current ->
      current.copy(
        players = current.players.map { it.copy(totalScore = 0, roundScore = 0, isChitTapped = false) },
        currentRound = 1,
        roundHistory = emptyList(),
        suspectedPlayerId = null,
        isGuessConfirmed = false,
        isChorRevealed = false,
        hasScoredCurrentRound = false,
        lastGuessResult = null
      )
    }
  }

  fun toggleSound() {
    val next = !_isSoundOn.value
    prefs.isSoundEnabled = next
    _isSoundOn.value = next
    if (next) sounds.playButtonClick()
  }

  fun toggleVibration() {
    val next = !_isVibrationOn.value
    prefs.isVibrationEnabled = next
    _isVibrationOn.value = next
    if (next) haptics.vibrateClick()
  }
}
