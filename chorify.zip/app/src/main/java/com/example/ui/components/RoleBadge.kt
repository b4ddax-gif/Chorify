package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Role
import com.example.ui.theme.ChorRed
import com.example.ui.theme.ChorRedContainer
import com.example.ui.theme.HiddenRoleContainer
import com.example.ui.theme.HiddenRoleGray
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MantriGreenContainer
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueContainer
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer

@Composable
fun RoleBadge(
  role: Role?,
  modifier: Modifier = Modifier,
  isExplicitlyRevealed: Boolean = false,
  showLabel: Boolean = true
) {
  // If role is null or not revealed and not inherently public, show HIDDEN
  val isPublic = role != null && (role.isVisibleImmediately || isExplicitlyRevealed)

  val (bgColor, borderColor, textColor, icon, label) = when {
    !isPublic -> BadgeConfig(
      bgColor = HiddenRoleContainer,
      borderColor = HiddenRoleGray.copy(alpha = 0.5f),
      textColor = HiddenRoleGray,
      icon = Icons.Default.VisibilityOff,
      label = "HIDDEN ROLE"
    )
    role == Role.RAJA -> BadgeConfig(
      bgColor = RajaGoldContainer,
      borderColor = RajaGold,
      textColor = RajaGold,
      icon = Icons.Default.WorkspacePremium,
      label = "RAJA"
    )
    role == Role.POLICE -> BadgeConfig(
      bgColor = PoliceBlueContainer,
      borderColor = PoliceBlue,
      textColor = PoliceBlue,
      icon = Icons.Default.LocalPolice,
      label = "POLICE"
    )
    role == Role.MANTRI -> BadgeConfig(
      bgColor = MantriGreenContainer,
      borderColor = MantriGreen,
      textColor = MantriGreen,
      icon = Icons.Default.MenuBook,
      label = "MANTRI"
    )
    role == Role.CHOR -> BadgeConfig(
      bgColor = ChorRedContainer,
      borderColor = ChorRed,
      textColor = ChorRed,
      icon = Icons.Default.Lock,
      label = "CHOR"
    )
    else -> BadgeConfig(
      bgColor = HiddenRoleContainer,
      borderColor = HiddenRoleGray,
      textColor = HiddenRoleGray,
      icon = Icons.Default.HelpOutline,
      label = "UNKNOWN"
    )
  }

  Box(
    modifier = modifier
      .clip(RoundedCornerShape(8.dp))
      .background(bgColor)
      .border(1.dp, borderColor, RoundedCornerShape(8.dp))
      .padding(horizontal = 10.dp, vertical = 5.dp),
    contentAlignment = Alignment.Center
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = icon,
        contentDescription = label,
        tint = textColor,
        modifier = Modifier.size(16.dp)
      )
      if (showLabel) {
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = label,
          color = textColor,
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp
        )
      }
    }
  }
}

private data class BadgeConfig(
  val bgColor: Color,
  val borderColor: Color,
  val textColor: Color,
  val icon: ImageVector,
  val label: String
)
