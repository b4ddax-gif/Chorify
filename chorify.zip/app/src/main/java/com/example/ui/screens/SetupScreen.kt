package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryBorderActive
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun SetupScreen(
  players: List<Player>,
  onUpdatePlayerName: (index: Int, name: String) -> Unit,
  onStartGameClick: () -> Unit,
  onBackClick: () -> Unit,
  isSoundOn: Boolean,
  onSoundToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  val focusManager = LocalFocusManager.current
  val isStartEnabled = players.size == 4 && players.all { it.name.trim().isNotEmpty() }

  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = "PLAYER SETUP",
        subtitle = "Enter 4 Player Names",
        showBack = true,
        isSoundOn = isSoundOn,
        onBackClick = onBackClick,
        onSoundToggle = onSoundToggle
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 500.dp)
          .padding(horizontal = 24.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Header info
        Box(
          modifier = Modifier
            .size(64.dp)
            .clip(CircleShape)
            .background(MysteryElevatedSurface)
            .border(1.5.dp, RajaGold, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.Group,
            contentDescription = "4 Players",
            tint = RajaGold,
            modifier = Modifier.size(32.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = "THE 4 PARTICIPANTS",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Serif,
          letterSpacing = 1.5.sp,
          color = RajaGold
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "Each player will receive a secret role chit on this device.",
          fontSize = 13.sp,
          color = TextSecondary
        )

        Spacer(modifier = Modifier.height(24.dp))

        // 4 Player Name Inputs
        players.forEachIndexed { index, player ->
          PlayerNameInputCard(
            playerNumber = index + 1,
            name = player.name,
            onNameChange = { onUpdatePlayerName(index, it) },
            isLast = index == players.lastIndex,
            onDone = { focusManager.clearFocus() }
          )
          Spacer(modifier = Modifier.height(14.dp))
        }

        Spacer(modifier = Modifier.height(20.dp))

        ChorifyButton(
          text = "START GAME",
          onClick = {
            focusManager.clearFocus()
            onStartGameClick()
          },
          enabled = isStartEnabled,
          style = ButtonStyle.PRIMARY_GOLD,
          testTag = "setup_start_game_button"
        )

        if (!isStartEnabled) {
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Please enter valid names for all 4 players to start.",
            fontSize = 12.sp,
            color = TextMuted
          )
        }

        Spacer(modifier = Modifier.height(32.dp))
      }
    }
  }
}

@Composable
private fun PlayerNameInputCard(
  playerNumber: Int,
  name: String,
  onNameChange: (String) -> Unit,
  isLast: Boolean,
  onDone: () -> Unit
) {
  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
    border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .clip(CircleShape)
          .background(MysteryElevatedSurface)
          .border(1.dp, MysteryBorderActive, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "$playerNumber",
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold,
          color = RajaGold
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      OutlinedTextField(
        value = name,
        onValueChange = {
          if (it.length <= 18) {
            onNameChange(it)
          }
        },
        placeholder = {
          Text(
            text = "Player $playerNumber",
            color = TextMuted,
            fontSize = 14.sp
          )
        },
        singleLine = true,
        keyboardOptions = KeyboardOptions(
          imeAction = if (isLast) ImeAction.Done else ImeAction.Next
        ),
        keyboardActions = KeyboardActions(
          onDone = { onDone() }
        ),
        colors = OutlinedTextFieldDefaults.colors(
          focusedTextColor = TextPrimary,
          unfocusedTextColor = TextPrimary,
          focusedBorderColor = RajaGold,
          unfocusedBorderColor = MysteryBorder,
          cursorColor = RajaGold,
          focusedContainerColor = MysteryElevatedSurface,
          unfocusedContainerColor = MysteryElevatedSurface
        ),
        modifier = Modifier
          .weight(1f)
          .testTag("player_input_$playerNumber")
      )
    }
  }
}
