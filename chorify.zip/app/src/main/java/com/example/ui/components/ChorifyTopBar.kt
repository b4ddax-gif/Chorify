package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ChorifyTopBar(
  title: String = "CHORIFY",
  subtitle: String? = null,
  showBack: Boolean = true,
  isSoundOn: Boolean = true,
  onBackClick: () -> Unit = {},
  onScoreboardClick: (() -> Unit)? = null,
  onSoundToggle: (() -> Unit)? = null,
  onSettingsClick: (() -> Unit)? = null,
  modifier: Modifier = Modifier
) {
  Box(
    modifier = modifier
      .fillMaxWidth()
      .background(MysteryDarkSurface)
      .statusBarsPadding()
      .padding(horizontal = 8.dp, vertical = 6.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (showBack) {
        IconButton(
          onClick = onBackClick,
          modifier = Modifier.testTag("top_bar_back_button")
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = TextPrimary
          )
        }
      } else {
        Spacer(modifier = Modifier.width(8.dp))
      }

      Column(
        modifier = Modifier.weight(1f)
      ) {
        Text(
          text = title,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Serif,
          letterSpacing = 2.sp,
          color = RajaGold
        )
        if (subtitle != null) {
          Text(
            text = subtitle,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TextSecondary,
            letterSpacing = 0.5.sp
          )
        }
      }

      if (onSoundToggle != null) {
        IconButton(
          onClick = onSoundToggle,
          modifier = Modifier.testTag("top_bar_sound_button")
        ) {
          Icon(
            imageVector = if (isSoundOn) Icons.Default.VolumeUp else Icons.Default.VolumeMute,
            contentDescription = if (isSoundOn) "Mute Sound" else "Enable Sound",
            tint = if (isSoundOn) TextPrimary else TextSecondary,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      if (onScoreboardClick != null) {
        IconButton(
          onClick = onScoreboardClick,
          modifier = Modifier.testTag("top_bar_scoreboard_button")
        ) {
          Icon(
            imageVector = Icons.Default.Leaderboard,
            contentDescription = "Scoreboard",
            tint = TextPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }

      if (onSettingsClick != null) {
        IconButton(
          onClick = onSettingsClick,
          modifier = Modifier.testTag("top_bar_settings_button")
        ) {
          Icon(
            imageVector = Icons.Default.Settings,
            contentDescription = "Settings",
            tint = TextPrimary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }
}
