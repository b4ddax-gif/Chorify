package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Player
import com.example.data.model.Role
import com.example.ui.theme.ChorRed
import com.example.ui.theme.ChorRedContainer
import com.example.ui.theme.HiddenRoleContainer
import com.example.ui.theme.HiddenRoleGray
import com.example.ui.theme.MantriGreen
import com.example.ui.theme.MantriGreenContainer
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryBorderActive
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.PoliceBlue
import com.example.ui.theme.PoliceBlueContainer
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

enum class CornerPosition(val label: String) {
  TOP_LEFT("Top-Left"),
  TOP_RIGHT("Top-Right"),
  BOTTOM_LEFT("Bottom-Left"),
  BOTTOM_RIGHT("Bottom-Right")
}

@Composable
fun CornerChitCard(
  player: Player,
  corner: CornerPosition,
  isSuspected: Boolean,
  isGuessConfirmed: Boolean,
  isChorRevealed: Boolean,
  onChitTap: () -> Unit,
  onSuspectSelect: () -> Unit,
  modifier: Modifier = Modifier
) {
  val role = player.currentRole
  val isFaceDown = !player.isChitTapped && !isChorRevealed

  // STRICT CRITICAL ROLE VISIBILITY RULES:
  // - If face-down: Show folded chit, "TAP TO OPEN".
  // - If tapped before final reveal:
  //   - RAJA -> "RAJA" (Public to everyone)
  //   - POLICE -> "POLICE" (Public to everyone)
  //   - MANTRI -> "ROLE HIDDEN" / "???" (NEVER show "MANTRI")
  //   - CHOR -> "ROLE HIDDEN" / "???" (NEVER show "CHOR")
  // - If final reveal (isChorRevealed):
  //   - RAJA -> "RAJA"
  //   - POLICE -> "POLICE"
  //   - MANTRI -> "MANTRI"
  //   - CHOR -> "CHOR"

  val isPublicRevealed = isChorRevealed || role == Role.RAJA || role == Role.POLICE

  val displayRoleTitle = when {
    isFaceDown -> "FACE DOWN"
    !isPublicRevealed -> "ROLE HIDDEN"
    role == Role.RAJA -> "RAJA"
    role == Role.POLICE -> "POLICE"
    role == Role.MANTRI -> "MANTRI"
    role == Role.CHOR -> "CHOR"
    else -> "UNKNOWN"
  }

  // Content description must strictly protect hidden identities!
  val safeContentDescription = when {
    isFaceDown -> "${player.name} secret chit, face down, tap to open"
    !isPublicRevealed -> "${player.name} role is hidden"
    role == Role.RAJA -> "${player.name} is Raja"
    role == Role.POLICE -> "${player.name} is Police"
    role == Role.MANTRI -> "${player.name} is Mantri"
    role == Role.CHOR -> "${player.name} is Chor"
    else -> "${player.name} chit"
  }

  val accentColor = when {
    isFaceDown -> RajaGold.copy(alpha = 0.7f)
    !isPublicRevealed -> HiddenRoleGray
    role == Role.RAJA -> RajaGold
    role == Role.POLICE -> PoliceBlue
    role == Role.MANTRI -> MantriGreen
    role == Role.CHOR -> ChorRed
    else -> HiddenRoleGray
  }

  val containerColor = when {
    isFaceDown -> MysteryDarkSurface
    isSuspected -> ChorRedContainer.copy(alpha = 0.6f)
    !isPublicRevealed -> HiddenRoleContainer
    role == Role.RAJA -> RajaGoldContainer.copy(alpha = 0.5f)
    role == Role.POLICE -> PoliceBlueContainer.copy(alpha = 0.5f)
    role == Role.MANTRI -> MantriGreenContainer.copy(alpha = 0.5f)
    role == Role.CHOR -> ChorRedContainer.copy(alpha = 0.7f)
    else -> MysteryDarkSurface
  }

  val borderColor by animateColorAsState(
    targetValue = when {
      isSuspected && isGuessConfirmed -> ChorRed
      isSuspected -> ChorRed.copy(alpha = 0.8f)
      isChorRevealed && role == Role.CHOR -> ChorRed
      isChorRevealed && role == Role.MANTRI -> MantriGreen
      player.isChitTapped && role == Role.RAJA -> RajaGold
      player.isChitTapped && role == Role.POLICE -> PoliceBlue
      player.isChitTapped -> HiddenRoleGray.copy(alpha = 0.6f)
      else -> MysteryBorder
    },
    label = "corner_border"
  )

  Card(
    shape = RoundedCornerShape(16.dp),
    colors = CardDefaults.cardColors(containerColor = containerColor),
    border = androidx.compose.foundation.BorderStroke(
      width = if (isSuspected || (isChorRevealed && (role == Role.CHOR || role == Role.MANTRI))) 2.dp else 1.dp,
      color = borderColor
    ),
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable {
        if (isFaceDown) {
          onChitTap()
        } else if (!isChorRevealed) {
          // Allow toggling suspect selection by tapping
          onSuspectSelect()
        }
      }
      .semantics {
        contentDescription = safeContentDescription
      }
      .testTag("corner_card_${player.id}")
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(10.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top row: Player name & Total score badge
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = player.name,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
          Text(
            text = corner.label,
            fontSize = 9.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextMuted,
            letterSpacing = 0.5.sp
          )
        }

        Box(
          modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .background(MysteryElevatedSurface)
            .border(0.5.dp, MysteryBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
            text = "${player.totalScore} PTS",
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold,
            color = RajaGold
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      // Center Chit Badge / Icon
      Box(
        modifier = Modifier
          .size(44.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.15f))
          .border(1.5.dp, accentColor.copy(alpha = 0.7f), CircleShape),
        contentAlignment = Alignment.Center
      ) {
        val icon = when {
          isFaceDown -> Icons.Default.TouchApp
          !isPublicRevealed -> Icons.Default.VisibilityOff
          role == Role.RAJA -> Icons.Default.WorkspacePremium
          role == Role.POLICE -> Icons.Default.LocalPolice
          role == Role.MANTRI -> Icons.Default.MenuBook
          role == Role.CHOR -> Icons.Default.Lock
          else -> Icons.Default.HelpOutline
        }

        Icon(
          imageVector = icon,
          contentDescription = null, // parent card semantics already describe it safely
          tint = accentColor,
          modifier = Modifier.size(24.dp)
        )
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Role Title or Face-down state
      Text(
        text = if (isFaceDown) "TAP TO OPEN" else displayRoleTitle,
        fontSize = if (isFaceDown) 11.sp else 12.sp,
        fontWeight = FontWeight.Bold,
        fontFamily = FontFamily.Serif,
        color = if (isFaceDown) RajaGold else accentColor,
        letterSpacing = 1.sp,
        textAlign = TextAlign.Center,
        maxLines = 1
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Bottom status indicator (Suspected / Points / Tap instruction)
      when {
        isChorRevealed -> {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(accentColor.copy(alpha = 0.2f))
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = "+${player.roundScore} PTS",
              fontSize = 10.sp,
              fontWeight = FontWeight.Bold,
              color = accentColor
            )
          }
        }
        isSuspected -> {
          Box(
            modifier = Modifier
              .clip(RoundedCornerShape(4.dp))
              .background(ChorRed)
              .padding(horizontal = 6.dp, vertical = 2.dp)
          ) {
            Text(
              text = if (isGuessConfirmed) "CONFIRMED SUSPECT" else "SUSPECTED",
              fontSize = 9.sp,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }
        }
        !isFaceDown && !isChorRevealed && isPublicRevealed -> {
          Text(
            text = "PUBLIC",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = accentColor.copy(alpha = 0.8f)
          )
        }
        !isFaceDown && !isChorRevealed -> {
          Text(
            text = "SECRET",
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            color = HiddenRoleGray.copy(alpha = 0.8f)
          )
        }
        else -> {
          Text(
            text = "CHIT SEALED",
            fontSize = 9.sp,
            color = TextMuted
          )
        }
      }
    }
  }
}
