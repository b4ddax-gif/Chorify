package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Leaderboard
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.GameState
import com.example.data.model.Player
import com.example.ui.components.ButtonStyle
import com.example.ui.components.ChorifyButton
import com.example.ui.components.ChorifyTopBar
import com.example.ui.theme.MysteryBlack
import com.example.ui.theme.MysteryBorder
import com.example.ui.theme.MysteryDarkSurface
import com.example.ui.theme.MysteryElevatedSurface
import com.example.ui.theme.RajaGold
import com.example.ui.theme.RajaGoldContainer
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ScoreboardScreen(
  state: GameState,
  isFinalMatchScoreboard: Boolean,
  onBackClick: () -> Unit,
  onHomeClick: () -> Unit,
  onStartNewGameClick: () -> Unit,
  isSoundOn: Boolean,
  onSoundToggle: () -> Unit,
  modifier: Modifier = Modifier
) {
  // Sort players by total score descending for display
  val sortedPlayers = state.players.sortedByDescending { it.totalScore }
  val champion = sortedPlayers.firstOrNull()

  Scaffold(
    topBar = {
      ChorifyTopBar(
        title = if (isFinalMatchScoreboard) "FINAL RESULTS" else "SCOREBOARD",
        subtitle = "Round ${state.currentRound}",
        showBack = !isFinalMatchScoreboard,
        isSoundOn = isSoundOn,
        onBackClick = onBackClick,
        onSoundToggle = onSoundToggle
      )
    },
    containerColor = MysteryBlack,
    modifier = modifier.fillMaxSize()
  ) { paddingValues ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(paddingValues)
        .navigationBarsPadding(),
      contentAlignment = Alignment.TopCenter
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 520.dp)
          .padding(horizontal = 20.dp)
          .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Crown / Trophy Header
        Box(
          modifier = Modifier
            .size(76.dp)
            .clip(CircleShape)
            .background(RajaGoldContainer)
            .border(2.dp, RajaGold, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = if (isFinalMatchScoreboard) Icons.Default.EmojiEvents else Icons.Default.Leaderboard,
            contentDescription = "Leaderboard",
            tint = RajaGold,
            modifier = Modifier.size(42.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
          text = if (isFinalMatchScoreboard) "CHAMPION OF THE MATCH" else "CURRENT STANDINGS",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Serif,
          letterSpacing = 1.5.sp,
          color = RajaGold,
          modifier = Modifier.testTag("scoreboard_header_title")
        )

        if (isFinalMatchScoreboard && champion != null) {
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "👑 ${champion.name} takes the throne with ${champion.totalScore} points!",
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary,
            textAlign = TextAlign.Center
          )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Leaderboard List
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          sortedPlayers.forEachIndexed { rankIndex, player ->
            ScoreboardRankCard(
              rank = rankIndex + 1,
              player = player,
              isChampion = isFinalMatchScoreboard && rankIndex == 0
            )
          }
        }

        // Round history section if available
        if (state.roundHistory.isNotEmpty()) {
          Spacer(modifier = Modifier.height(24.dp))

          Text(
            text = "ROUND ARCHIVE",
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold,
            color = TextMuted,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.Start)
          )

          Spacer(modifier = Modifier.height(8.dp))

          Card(
            shape = RoundedCornerShape(14.dp),
            colors = CardDefaults.cardColors(containerColor = MysteryDarkSurface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MysteryBorder),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              state.roundHistory.forEachIndexed { idx, item ->
                Row(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 6.dp),
                  verticalAlignment = Alignment.CenterVertically
                ) {
                  Text(
                    text = "R${item.roundNumber}",
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = RajaGold,
                    modifier = Modifier.width(32.dp)
                  )
                  Text(
                    text = "Chor: ${item.chorName}",
                    fontSize = 12.sp,
                    color = TextPrimary,
                    modifier = Modifier.weight(1f)
                  )
                  Text(
                    text = if (item.policeWon) "Police Caught (+100)" else "Chor Escaped (+100)",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (item.policeWon) RajaGold else TextSecondary
                  )
                }
                if (idx < state.roundHistory.lastIndex) {
                  HorizontalDivider(
                    thickness = 0.5.dp,
                    color = MysteryBorder.copy(alpha = 0.4f),
                    modifier = Modifier.padding(vertical = 2.dp)
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(30.dp))

        if (isFinalMatchScoreboard) {
          ChorifyButton(
            text = "PLAY AGAIN",
            onClick = onStartNewGameClick,
            style = ButtonStyle.PRIMARY_GOLD,
            testTag = "scoreboard_play_again_button"
          )

          Spacer(modifier = Modifier.height(12.dp))

          ChorifyButton(
            text = "MAIN MENU",
            onClick = onHomeClick,
            style = ButtonStyle.SECONDARY_OUTLINE,
            testTag = "scoreboard_home_button"
          )
        } else {
          ChorifyButton(
            text = "BACK TO GAME",
            onClick = onBackClick,
            style = ButtonStyle.SURFACE_ELEVATED,
            testTag = "scoreboard_back_button"
          )
        }

        Spacer(modifier = Modifier.height(32.dp))
      }
    }
  }
}

@Composable
private fun ScoreboardRankCard(
  rank: Int,
  player: Player,
  isChampion: Boolean
) {
  val rankColor = when (rank) {
    1 -> RajaGold
    2 -> Color(0xFFC0C0C0) // Silver
    3 -> Color(0xFFCD7F32) // Bronze
    else -> TextMuted
  }

  Card(
    shape = RoundedCornerShape(14.dp),
    colors = CardDefaults.cardColors(
      containerColor = if (isChampion) RajaGoldContainer.copy(alpha = 0.35f) else MysteryDarkSurface
    ),
    border = androidx.compose.foundation.BorderStroke(
      width = if (isChampion) 1.5.dp else 1.dp,
      color = if (isChampion) RajaGold else MysteryBorder
    ),
    modifier = Modifier
      .fillMaxWidth()
      .testTag("rank_card_${player.id}")
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(MysteryElevatedSurface)
          .border(1.dp, rankColor, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "#$rank",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = rankColor
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Text(
        text = player.name,
        fontSize = 15.sp,
        fontWeight = FontWeight.Bold,
        color = TextPrimary,
        modifier = Modifier.weight(1f)
      )

      Column(horizontalAlignment = Alignment.End) {
        Text(
          text = "${player.totalScore}",
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Serif,
          color = if (isChampion) RajaGold else TextPrimary
        )
        Text(
          text = "POINTS",
          fontSize = 10.sp,
          fontWeight = FontWeight.Bold,
          letterSpacing = 1.sp,
          color = TextMuted
        )
      }
    }
  }
}
