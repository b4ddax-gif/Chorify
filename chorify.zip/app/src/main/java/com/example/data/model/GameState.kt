package com.example.data.model

enum class Screen {
  HOME,
  HOW_TO_PLAY,
  SETTINGS,
  SCOREBOARD,
  PLAYER_SETUP,
  MAIN_GAME,
  ROUND_RESULT,
  FINAL_SCOREBOARD
}

data class GuessResult(
  val suspectedPlayerId: Int?,
  val suspectedPlayerName: String?,
  val isCorrect: Boolean,
  val actualChorPlayer: Player,
  val actualMantriPlayer: Player,
  val pointsAwardedPolice: Int,
  val pointsAwardedChor: Int,
  val pointsAwardedMantri: Int,
  val pointsAwardedRaja: Int
)

data class RoundHistoryItem(
  val roundNumber: Int,
  val rajaName: String,
  val policeName: String,
  val chorName: String,
  val mantriName: String,
  val suspectedName: String?,
  val policeWon: Boolean
)

data class GameState(
  val currentScreen: Screen = Screen.HOME,
  val previousScreen: Screen = Screen.HOME,
  val players: List<Player> = listOf(
    Player(id = 1, name = "PLAYER 1"),
    Player(id = 2, name = "PLAYER 2"),
    Player(id = 3, name = "PLAYER 3"),
    Player(id = 4, name = "PLAYER 4")
  ),
  val currentRound: Int = 1,
  val suspectedPlayerId: Int? = null,
  val isGuessConfirmed: Boolean = false,
  val isChorRevealed: Boolean = false,
  val hasScoredCurrentRound: Boolean = false,
  val lastGuessResult: GuessResult? = null,
  val roundHistory: List<RoundHistoryItem> = emptyList(),
  val showRevealConfirmDialog: Boolean = false,
  val isRevealAnimating: Boolean = false
) {
  val playerTopLeft: Player? get() = players.getOrNull(0)
  val playerTopRight: Player? get() = players.getOrNull(1)
  val playerBottomLeft: Player? get() = players.getOrNull(2)
  val playerBottomRight: Player? get() = players.getOrNull(3)

  val rajaPlayer: Player?
    get() = players.firstOrNull { it.currentRole == Role.RAJA }

  val policePlayer: Player?
    get() = players.firstOrNull { it.currentRole == Role.POLICE }

  val chorPlayer: Player?
    get() = players.firstOrNull { it.currentRole == Role.CHOR }

  val mantriPlayer: Player?
    get() = players.firstOrNull { it.currentRole == Role.MANTRI }
}
