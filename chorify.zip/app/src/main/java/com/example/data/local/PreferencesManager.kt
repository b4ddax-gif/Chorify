package com.example.data.local

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {
  private val prefs: SharedPreferences =
    context.getSharedPreferences("chorify_prefs", Context.MODE_PRIVATE)

  var isSoundEnabled: Boolean
    get() = prefs.getBoolean(KEY_SOUND, true)
    set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

  var isVibrationEnabled: Boolean
    get() = prefs.getBoolean(KEY_VIBRATION, true)
    set(value) = prefs.edit().putBoolean(KEY_VIBRATION, value).apply()

  fun getPlayerName(index: Int, defaultName: String): String {
    return prefs.getString("${KEY_PLAYER_PREFIX}$index", defaultName) ?: defaultName
  }

  fun savePlayerName(index: Int, name: String) {
    prefs.edit().putString("${KEY_PLAYER_PREFIX}$index", name.trim()).apply()
  }

  fun clearAll() {
    prefs.edit().clear().apply()
  }

  companion object {
    private const val KEY_SOUND = "key_sound_enabled"
    private const val KEY_VIBRATION = "key_vibration_enabled"
    private const val KEY_PLAYER_PREFIX = "key_player_name_"
  }
}
