package com.example.data.model

data class Player(
  val id: Int,
  val name: String,
  val currentRole: Role? = null,
  val isChitTapped: Boolean = false,
  val totalScore: Int = 0,
  val roundScore: Int = 0
) {
  val isRaja: Boolean get() = currentRole == Role.RAJA
  val isPolice: Boolean get() = currentRole == Role.POLICE
  val isChor: Boolean get() = currentRole == Role.CHOR
  val isMantri: Boolean get() = currentRole == Role.MANTRI
  val isHiddenRole: Boolean get() = currentRole == Role.CHOR || currentRole == Role.MANTRI
}
