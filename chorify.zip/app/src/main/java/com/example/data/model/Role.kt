package com.example.data.model

enum class Role(
  val displayName: String,
  val pointsParticipation: Int,
  val isVisibleImmediately: Boolean
) {
  RAJA(
    displayName = "RAJA",
    pointsParticipation = 25,
    isVisibleImmediately = true
  ),
  MANTRI(
    displayName = "MANTRI",
    pointsParticipation = 50,
    isVisibleImmediately = false
  ),
  CHOR(
    displayName = "CHOR",
    pointsParticipation = 0,
    isVisibleImmediately = false
  ),
  POLICE(
    displayName = "POLICE",
    pointsParticipation = 0,
    isVisibleImmediately = true
  );

  companion object {
    /**
     * Returns a strictly shuffled set of all 4 roles.
     * Guaranteed to contain exactly one of each: RAJA, MANTRI, CHOR, POLICE.
     */
    fun createShuffledRoles(previousDistribution: List<Role>? = null): List<Role> {
      val base = entries.toList()
      var shuffled = base.shuffled()
      // If previous distribution existed, ensure the new round is not identical if possible
      if (previousDistribution != null && previousDistribution.size == 4 && base.size == 4) {
        var attempts = 0
        while (shuffled == previousDistribution && attempts < 10) {
          shuffled = base.shuffled()
          attempts++
        }
      }
      return shuffled
    }
  }
}
