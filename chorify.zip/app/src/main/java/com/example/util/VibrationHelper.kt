package com.example.util

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager

class VibrationHelper(
  private val context: Context,
  private val isVibrationEnabled: () -> Boolean
) {
  private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
    val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
    vibratorManager?.defaultVibrator
  } else {
    @Suppress("DEPRECATION")
    context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
  }

  fun vibrateClick() {
    if (!isVibrationEnabled()) return
    vibratePattern(durationMs = 18, amplitude = 70)
  }

  fun vibrateChit() {
    if (!isVibrationEnabled()) return
    vibratePattern(durationMs = 40, amplitude = 120)
  }

  fun vibrateConfirm() {
    if (!isVibrationEnabled()) return
    vibratePattern(durationMs = 60, amplitude = 180)
  }

  fun vibrateReveal() {
    if (!isVibrationEnabled()) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val timings = longArrayOf(0, 70, 60, 140)
      val amplitudes = intArrayOf(0, 150, 0, 255)
      vibrator?.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
    } else {
      @Suppress("DEPRECATION")
      vibrator?.vibrate(longArrayOf(0, 70, 60, 140), -1)
    }
  }

  private fun vibratePattern(durationMs: Long, amplitude: Int) {
    if (vibrator?.hasVibrator() != true) return
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      vibrator.vibrate(
        VibrationEffect.createOneShot(
          durationMs,
          amplitude.coerceIn(1, 255)
        )
      )
    } else {
      @Suppress("DEPRECATION")
      vibrator.vibrate(durationMs)
    }
  }
}
