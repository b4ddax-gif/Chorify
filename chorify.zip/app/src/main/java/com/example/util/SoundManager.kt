package com.example.util

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SoundManager(private val isSoundEnabled: () -> Boolean) {
  private val scope = CoroutineScope(Dispatchers.Default)
  private val sampleRate = 44100

  fun playButtonClick() {
    if (!isSoundEnabled()) return
    scope.launch {
      playTone(frequency = 700.0, durationMs = 25, attackMs = 2, decayMs = 23)
    }
  }

  fun playChitShuffle() {
    if (!isSoundEnabled()) return
    scope.launch {
      playNoiseBurst(durationMs = 120)
    }
  }

  fun playChitFlip() {
    if (!isSoundEnabled()) return
    scope.launch {
      playChirp(startFreq = 440.0, endFreq = 880.0, durationMs = 70)
    }
  }

  fun playSuspenseDrone() {
    if (!isSoundEnabled()) return
    scope.launch {
      playTone(frequency = 180.0, durationMs = 300, attackMs = 40, decayMs = 260)
    }
  }

  fun playReveal(isPoliceCorrect: Boolean) {
    if (!isSoundEnabled()) return
    scope.launch {
      if (isPoliceCorrect) {
        // Triumphant chord (C5 - E5 - G5)
        playTone(frequency = 523.25, durationMs = 120, attackMs = 10, decayMs = 110)
        playTone(frequency = 659.25, durationMs = 140, attackMs = 10, decayMs = 130)
        playTone(frequency = 783.99, durationMs = 240, attackMs = 10, decayMs = 230)
      } else {
        // Mysterious escape tone (C4 - D#4 - F#4)
        playTone(frequency = 261.63, durationMs = 140, attackMs = 10, decayMs = 130)
        playTone(frequency = 311.13, durationMs = 160, attackMs = 10, decayMs = 150)
        playTone(frequency = 369.99, durationMs = 260, attackMs = 10, decayMs = 250)
      }
    }
  }

  fun playScoreTick() {
    if (!isSoundEnabled()) return
    scope.launch {
      playTone(frequency = 980.0, durationMs = 45, attackMs = 5, decayMs = 40)
    }
  }

  private fun playTone(frequency: Double, durationMs: Int, attackMs: Int, decayMs: Int) {
    try {
      val numSamples = (sampleRate * durationMs) / 1000
      val samples = ShortArray(numSamples)
      val attackSamples = (sampleRate * attackMs) / 1000
      val decaySamples = (sampleRate * decayMs) / 1000

      for (i in 0 until numSamples) {
        val angle = 2.0 * PI * i / (sampleRate / frequency)
        val rawSine = sin(angle)
        // Envelope
        val env = when {
          i < attackSamples -> i.toFloat() / attackSamples.coerceAtLeast(1)
          i > numSamples - decaySamples -> (numSamples - i).toFloat() / decaySamples.coerceAtLeast(1)
          else -> 1.0f
        }
        samples[i] = (rawSine * env * 24000).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
      }

      val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ).coerceAtLeast(numSamples * 2)

      val audioTrack = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(bufferSize)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()

      audioTrack.write(samples, 0, samples.size)
      audioTrack.play()
      // Release after playing
      Thread.sleep((durationMs + 20).toLong())
      audioTrack.stop()
      audioTrack.release()
    } catch (_: Exception) {
      // Audio fallback safe
    }
  }

  private fun playChirp(startFreq: Double, endFreq: Double, durationMs: Int) {
    try {
      val numSamples = (sampleRate * durationMs) / 1000
      val samples = ShortArray(numSamples)

      for (i in 0 until numSamples) {
        val progress = i.toDouble() / numSamples
        val currentFreq = startFreq + (endFreq - startFreq) * progress
        val angle = 2.0 * PI * i / (sampleRate / currentFreq)
        val envelope = sin(PI * progress) // Half sine envelope
        samples[i] = (sin(angle) * envelope * 20000).toInt().toShort()
      }

      val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ).coerceAtLeast(numSamples * 2)

      val track = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(bufferSize)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()

      track.write(samples, 0, samples.size)
      track.play()
      Thread.sleep((durationMs + 20).toLong())
      track.stop()
      track.release()
    } catch (_: Exception) {
      // Audio fallback safe
    }
  }

  private fun playNoiseBurst(durationMs: Int) {
    try {
      val numSamples = (sampleRate * durationMs) / 1000
      val samples = ShortArray(numSamples)
      val random = Random(System.currentTimeMillis())

      for (i in 0 until numSamples) {
        val progress = i.toDouble() / numSamples
        val envelope = (1.0 - progress) * (1.0 - progress) // Exponential decay
        val noise = (random.nextDouble() * 2.0 - 1.0)
        samples[i] = (noise * envelope * 14000).toInt().toShort()
      }

      val bufferSize = AudioTrack.getMinBufferSize(
        sampleRate,
        AudioFormat.CHANNEL_OUT_MONO,
        AudioFormat.ENCODING_PCM_16BIT
      ).coerceAtLeast(numSamples * 2)

      val track = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(bufferSize)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()

      track.write(samples, 0, samples.size)
      track.play()
      Thread.sleep((durationMs + 20).toLong())
      track.stop()
      track.release()
    } catch (_: Exception) {
      // Audio fallback safe
    }
  }
}
