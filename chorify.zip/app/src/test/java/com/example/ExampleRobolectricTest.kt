package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.Role
import com.example.ui.GameViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read string from context verifies CHORIFY app name`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("CHORIFY", appName)
  }

  @Test
  fun `role distribution contains exactly one of each role without duplicates`() {
    for (i in 1..50) {
      val roles = Role.createShuffledRoles()
      assertEquals(4, roles.size)
      assertEquals(1, roles.count { it == Role.RAJA })
      assertEquals(1, roles.count { it == Role.POLICE })
      assertEquals(1, roles.count { it == Role.MANTRI })
      assertEquals(1, roles.count { it == Role.CHOR })
    }
  }

  @Test
  fun `role visibility rules strictly protect Mantri and Chor identity`() {
    assertTrue("RAJA should be immediately visible", Role.RAJA.isVisibleImmediately)
    assertTrue("POLICE should be immediately visible", Role.POLICE.isVisibleImmediately)
    assertFalse("MANTRI must remain hidden from view", Role.MANTRI.isVisibleImmediately)
    assertFalse("CHOR must remain hidden from view", Role.CHOR.isVisibleImmediately)
  }

  @Test
  fun `participation points verify Raja gets 25 and Mantri gets 50`() {
    assertEquals(25, Role.RAJA.pointsParticipation)
    assertEquals(50, Role.MANTRI.pointsParticipation)
    assertEquals(0, Role.CHOR.pointsParticipation)
    assertEquals(0, Role.POLICE.pointsParticipation)
  }

  @Test
  fun `start new game places all chits face-down in four corners`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = GameViewModel(app)

    viewModel.startNewGameSession()
    val state = viewModel.state.value

    assertEquals(4, state.players.size)
    // All chits start face-down
    assertTrue(state.players.all { !it.isChitTapped })
    assertFalse(state.isChorRevealed)
    assertFalse(state.hasScoredCurrentRound)

    // Ensure 4 distinct corners have players assigned
    assertNotNull(state.playerTopLeft)
    assertNotNull(state.playerTopRight)
    assertNotNull(state.playerBottomLeft)
    assertNotNull(state.playerBottomRight)
  }

  @Test
  fun `tapping a chit flips it and reveals public roles or hides secret roles`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = GameViewModel(app)
    viewModel.startNewGameSession()

    val p1 = viewModel.state.value.players[0]
    assertFalse(p1.isChitTapped)

    viewModel.tapPlayerChit(p1.id)
    val updatedP1 = viewModel.state.value.players.first { it.id == p1.id }
    assertTrue(updatedP1.isChitTapped)
  }

  @Test
  fun `next round resets face-down chits and preserves scores and names`() {
    val app = ApplicationProvider.getApplicationContext<Application>()
    val viewModel = GameViewModel(app)
    viewModel.startNewGameSession()

    // Tap chits
    viewModel.tapPlayerChit(1)
    viewModel.tapPlayerChit(2)

    val round1 = viewModel.state.value.currentRound
    assertEquals(1, round1)

    // Start next round
    viewModel.startNextRound()
    val stateAfterNext = viewModel.state.value

    assertEquals(2, stateAfterNext.currentRound)
    // All chits must be face-down again
    assertTrue("All chits must reset to face-down", stateAfterNext.players.all { !it.isChitTapped })
    assertFalse(stateAfterNext.isChorRevealed)
    assertFalse(stateAfterNext.hasScoredCurrentRound)
    assertNull(stateAfterNext.suspectedPlayerId)
  }
}
